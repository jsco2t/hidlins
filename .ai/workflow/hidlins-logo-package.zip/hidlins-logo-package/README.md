# Hidlins Logo Package

This package contains a clean vector redraw based on the selected generated concepts.

## Masters
- `hidlins-mono.svg` / `.pdf` - monochrome line-art treatment
- `hidlins-navy.svg` / `.pdf` - light line art on dark navy
- `hidlins-vintage-dark.svg` / `.pdf` - cream vintage lock on charcoal

The SVG files are the canonical masters and use a 1024 x 1024 viewBox.

## Raster exports
Each treatment is exported at:
1024, 512, 256, 192, 180, 152, 128, 64, 60, 48, 32, and 16 px.

`favicon.ico` contains common favicon sizes using the navy treatment.

## Notes
The original concepts were AI-generated raster images. These files are a vector
redraw rather than an automatic trace, so tiny engraving details are deliberately
simplified to remain legible as application and favicon icons.
